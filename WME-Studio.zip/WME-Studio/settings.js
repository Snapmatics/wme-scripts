/* Shared by the isolated content script and the extension popup. */
(() => {
  'use strict';
  const defaults = Object.freeze({
    enabled: true, theme: 'waze', density: 'compact', corners: 'flat',
    accent: '#0099ff', sidebar: 330, addons: true, motion: true
  });
  const choices = { theme: ['waze', 'light', 'dark'], density: ['compact', 'comfortable'], corners: ['flat', 'soft'] };
  const prefix = 'wmeStudio.';
  function sanitize(input = {}) {
    const out = {};
    for (const [key, fallback] of Object.entries(defaults)) {
      const value = input[key];
      if (choices[key]) out[key] = choices[key].includes(value) ? value : fallback;
      else if (key === 'accent') out[key] = /^#[0-9a-f]{6}$/i.test(value || '') ? value.toLowerCase() : fallback;
      else if (key === 'sidebar') out[key] = Number.isFinite(value) ? Math.max(300, Math.min(420, Math.round(value / 10) * 10)) : fallback;
      else out[key] = typeof value === 'boolean' ? value : fallback;
    }
    return out;
  }
  async function read() {
    const keys = Object.fromEntries(Object.entries(defaults).map(([key, value]) => [prefix + key, value]));
    const stored = await chrome.storage.local.get(keys);
    return sanitize(Object.fromEntries(Object.keys(defaults).map(key => [key, stored[prefix + key]])));
  }
  async function write(patch) {
    const clean = sanitize(patch);
    const data = Object.fromEntries(Object.keys(defaults).filter(key => Object.hasOwn(patch, key)).map(key => [prefix + key, clean[key]]));
    await chrome.storage.local.set(data);
  }
  function changes(current, items) {
    const next = { ...current };
    for (const key of Object.keys(defaults)) if (items[prefix + key]) next[key] = items[prefix + key].newValue ?? defaults[key];
    return sanitize(next);
  }
  function ink(hex) {
    const rgb = hex.slice(1).match(/../g).map(v => parseInt(v, 16) / 255).map(v => v <= .04045 ? v / 12.92 : ((v + .055) / 1.055) ** 2.4);
    return rgb[0] * .2126 + rgb[1] * .7152 + rgb[2] * .0722 > .179 ? '#111820' : '#ffffff';
  }
  globalThis.WMEStudioSettings = Object.freeze({ defaults, sanitize, read, write, changes, ink });
})();
