WME STUDIO 1.0.3
A complete appearance extension for Waze Map Editor, built from your supplied September 2026 editor markup.

INSTALL IN GOOGLE CHROME
1. Extract the ZIP to a permanent folder.
2. Open chrome://extensions in Chrome.
3. Switch on Developer mode (top right).
4. Click Load unpacked and select the WME-Studio folder containing manifest.json.
5. Refresh your Waze Map Editor tab once.
6. Pin WME Studio from Chrome's Extensions menu. Click its icon to customize it.

UPDATE FROM AN EARLIER VERSION
1. Extract the new ZIP and copy the files inside WME-Studio into your existing installed WME-Studio folder, replacing the old files.
2. Open chrome://extensions and click Reload on WME Studio.
3. Refresh every open Waze Map Editor tab. The popup should show version 1.0.3.
Your existing appearance settings are retained when you update the same folder.

FIXES IN 1.0.3
- Logo back at the left next to the menu button; search box right after it (as in the default layout).

FIXES IN 1.0.2
- Waze Map Editor logo stays visible in the Light theme when Waze (or a dark-mode script) is dark.
- Logo vertically centered in the header; search box sits next to the logo again.
- Review, Google Places and other nav items: no square plate behind rounded corners.
- "Update results when map moves" footer, Visual instructions / Toward / Exit signs fields follow the theme.
- Street name field and its listen (TTS) button join as one control.
- "Why is this disabled?" and other rich tooltips use readable theme colors.

FIXES IN 1.0.1
- Vertically centered button labels and icons, consistent line heights, and matching hover corners.
- Consistent dropdown triggers, focus borders, row spacing, backgrounds, and scrollbars.
- One outlined category field containing both the selected chips and the editable input.
- A matching rectangular zoom-control group and centered location text.
- Native destructive-button colors and input error/success indicators are preserved.

WHAT CHANGES
- Coordinated toolbar, navigation, sidebar, forms, tabs, menus, layers, map controls, dialogs, and footer.
- A compact, flat default layout with a blue accent.
- Light and dark gray themes, or automatic matching to the Waze theme.
- Compact or relaxed spacing, flat or soft corners, and any accent color.
- Adjustable sidebar width, with the editor's map inset kept in step.
- Palette matching for supported add-on panels visible in the supplied source.
- Reduced motion, keyboard focus indicators, and readable accent-button text.

HOW IT WORKS
Native controls stay in their original DOM positions. WME Studio does not rebuild buttons, trigger actions, access Waze's internal API, alter editing permissions, or change map geometry, road colors, satellite images, save logic, and keyboard shortcuts. Disabled controls remain disabled.

The extension styles the page and Waze's open shadow-root components. Settings are kept locally with Chrome's storage permission. No accounts, analytics, remote scripts, background worker, or data collection are added.

SCOPE
Production and beta editors on www.waze.com, waze.com, and beta.waze.com, including language-prefixed editor routes. It does not run on the live map or other Waze pages. Chat content embedded in a separate origin and closed shadow roots cannot be reskinned by this extension. Native warning, error, road and map colors retain their meaning.

TURN OFF / TROUBLESHOOT
- Turn off the main switch in the popup to immediately remove the redesign. Your settings are retained.
- Reset appearance restores this extension's defaults only.
- If another extension also restyles WME, turn off its appearance feature first if styles conflict. Functional features can remain enabled.
- Refresh WME after installing, updating, or disabling/removing the extension in chrome://extensions. Existing content-script styling can otherwise remain until the page reloads.
- Waze can change component structure over time. If one panel looks wrong, send a screenshot and that panel's current HTML.

This is an independent community extension, not an official Waze or Google product.

VALIDATION
JavaScript syntax, stylesheet parsing, manifest assets, settings controls, and DOM regression checks passed against the supplied saved markup (489 Waze shadow components). Tests cover disabled controls, existing handlers, dynamic components, theme following, popup updates, and disabling the redesign. Ten additional native-style cascade fixtures check button alignment rules, hover corners, zoom sizing, dropdown states, compound category inputs, semantic colors, and the location strip. These are CSS/DOM simulations; browser visual inspection and a live signed-in editing session remain unverified.
