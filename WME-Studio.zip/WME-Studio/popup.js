(() => {
  'use strict';
  const config = globalThis.WMEStudioSettings;
  const $ = id => document.getElementById(id);
  const status = $('status');
  let current = { ...config.defaults };
  let saveVersion = 0;
  let pendingWrites = Promise.resolve();
  const system = matchMedia('(prefers-color-scheme: dark)');
  function render() {
    for (const key of ['enabled', 'addons', 'motion']) $(key).checked = current[key];
    $('appearance').disabled = !current.enabled;
    $('sidebar').value = current.sidebar;
    $('sidebar-value').textContent = current.sidebar + ' px';
    $('accent').value = current.accent;
    $('accent-value').textContent = current.accent.toUpperCase();
    document.documentElement.style.setProperty('--accent', current.accent);
    document.documentElement.style.setProperty('--on-accent', config.ink(current.accent));
    document.documentElement.dataset.theme = current.theme === 'waze' ? (system.matches ? 'dark' : 'light') : current.theme;
    document.querySelectorAll('[data-setting]').forEach(button => button.setAttribute('aria-pressed', String(current[button.dataset.setting] === button.dataset.value)));
  }
  function saved() { status.textContent = current.enabled ? 'Changes apply instantly to open editor tabs.' : 'Redesign paused. Waze’s original appearance is active.'; }
  function change(patch) {
    const previous = { ...current };
    current = config.sanitize({ ...current, ...patch });
    render();
    status.textContent = 'Saving…';
    const version = ++saveVersion;
    pendingWrites = pendingWrites.then(() => config.write(patch)).then(() => { if (version === saveVersion) saved(); }).catch(() => {
      if (version === saveVersion) { current = previous; render(); status.textContent = 'Could not save. Close and reopen this popup to retry.'; }
    });
  }
  $('appearance').disabled = true;
  $('enabled').disabled = true;
  $('reset').disabled = true;
  config.read().then(settings => {
    current = settings; render(); saved(); $('enabled').disabled = false; $('reset').disabled = false;
    document.querySelectorAll('[data-setting]').forEach(button => button.addEventListener('click', () => change({ [button.dataset.setting]: button.dataset.value })));
    for (const key of ['enabled', 'addons', 'motion']) $(key).addEventListener('change', event => change({ [key]: event.target.checked }));
    $('sidebar').addEventListener('input', event => { $('sidebar-value').textContent = event.target.value + ' px'; });
    $('sidebar').addEventListener('change', event => change({ sidebar: Number(event.target.value) }));
    $('accent').addEventListener('change', event => change({ accent: event.target.value }));
    $('reset').addEventListener('click', () => change({ ...config.defaults }));
  }).catch(() => { status.textContent = 'Could not load preferences. Reload the extension and try again.'; });
  system.addEventListener('change', render);
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local' && Object.keys(changes).some(key => key.startsWith('wmeStudio.'))) { current = config.changes(current, changes); render(); }
  });
})();
