/* Styles for Waze's open shadow roots. Every rule is gated by our root attribute. */
globalThis.WMEStudioComponents = String.raw`
:host-context(html[data-wme-studio="on"]) { font-family: var(--ws-font) !important; }
:host-context(html[data-wme-studio="on"]) :is(button,input,textarea,select) { font-family: var(--ws-font) !important; }
:host-context(html[data-wme-studio="on"]) :is(button,input,textarea,select):focus-visible { outline: 2px solid var(--ws-accent) !important; outline-offset: 2px; }
:host-context(html[data-wme-studio="on"]):host(wz-button) { border-radius: var(--ws-r-start, var(--ws-radius)) var(--ws-r-end, var(--ws-radius)) var(--ws-r-end, var(--ws-radius)) var(--ws-r-start, var(--ws-radius)) !important; vertical-align: middle; line-height: normal; }
:host-context(html[data-wme-studio="on"]) .wz-button {
  display: inline-flex !important; align-items: center !important; justify-content: center !important;
  border-radius: var(--ws-r-start, var(--ws-radius)) var(--ws-r-end, var(--ws-radius)) var(--ws-r-end, var(--ws-radius)) var(--ws-r-start, var(--ws-radius)) !important; box-sizing: border-box !important;
  font-size: 13px !important; font-weight: 600 !important; line-height: 20px !important;
  padding-block: 0 !important; letter-spacing: 0 !important;
  min-height: 24px;
  transition: background-color 120ms ease, box-shadow 120ms ease;
}
:host-context(html[data-wme-studio="on"]) .wz-button:is(.md,.sm,.lg) { height: var(--wz-button-height, var(--ws-control)) !important; }
:host-context(html[data-wme-studio="on"]) .wz-button:is(.md,.sm):not(.icon-only) { padding-inline: 13px !important; }
:host-context(html[data-wme-studio="on"]) .wz-button .button-text { display: inline-flex !important; align-items: center !important; justify-content: center; min-width: 0; font: inherit !important; line-height: 20px !important; }
:host-context(html[data-wme-studio="on"]) .wz-button .color-layer { border-radius: inherit !important; }
:host-context(html[data-wme-studio="on"]) .wz-button ::slotted(i.w-icon) { display: inline-flex; align-items: center; justify-content: center; line-height: 1 !important; flex-shrink: 0; }
:host-context(html[data-wme-studio="on"]) .wz-button:is(.clear-icon,.text):not(.alarming) { color: var(--ws-text) !important; }
:host-context(html[data-wme-studio="on"]) .wz-button.secondary:not(.alarming) { background: var(--ws-field) !important; border: 1px solid var(--ws-border) !important; color: var(--ws-text) !important; }
:host-context(html[data-wme-studio="on"]) .wz-button.primary:not(.alarming) { background: var(--ws-accent) !important; color: var(--ws-on-accent) !important; border-color: var(--ws-accent) !important; box-shadow: none !important; }
:host-context(html[data-wme-studio="on"]) .wz-button.shadowed:not(.alarming) { background: var(--ws-surface) !important; color: var(--ws-text) !important; border: 1px solid var(--ws-border); box-shadow: var(--ws-shadow) !important; }
:host-context(html[data-wme-studio="on"]) .wz-button:is(.clear-icon,.text,.secondary):hover:not(:disabled):not(.alarming) { background-color: var(--ws-hover) !important; }
:host-context(html[data-wme-studio="on"]) .wz-button:disabled { opacity: .45 !important; box-shadow: none !important; cursor: not-allowed; }
:host-context(html[data-wme-studio="on"]):host(.overlay-button) .wz-button { width: 38px !important; min-width: 38px !important; height: 38px !important; min-height: 38px; border: 1px solid var(--ws-border) !important; background: var(--ws-surface) !important; color: var(--ws-text) !important; box-shadow: var(--ws-shadow) !important; }
:host-context(html[data-wme-studio="on"]):host(.overlay-button-active) .wz-button { color: var(--ws-accent) !important; border-color: var(--ws-accent) !important; box-shadow: 0 0 0 1px var(--ws-accent) !important; }
:host-context(html[data-wme-studio="on"]):host(.zoom-button) .wz-button { width: 36px !important; min-width: 36px !important; height: 36px !important; min-height: 36px; border: 0 !important; border-radius: 0 !important; box-shadow: none !important; background: transparent; }
:host-context(html[data-wme-studio="on"]):host(.zoom-plus-button) .wz-button { border-radius: calc(var(--ws-radius) - 1px) calc(var(--ws-radius) - 1px) 0 0 !important; }
:host-context(html[data-wme-studio="on"]):host(.zoom-minus-button) .wz-button { border-radius: 0 0 calc(var(--ws-radius) - 1px) calc(var(--ws-radius) - 1px) !important; border-top: 1px solid var(--ws-border) !important; }
:host-context(html[data-wme-studio="on"]):host(.zoom-button) .color-layer { width: 100% !important; height: 100% !important; inset: 0; }
:host-context(html[data-wme-studio="on"]):host(#save-button) .wz-button { min-width: 76px; }

:host-context(html[data-wme-studio="on"]) .wz-header { height: var(--ws-header) !important; min-height: var(--ws-header); background: var(--ws-surface) !important; }
:host-context(html[data-wme-studio="on"]) .content-wrapper.drop-shadow { box-shadow: none !important; background: var(--ws-surface) !important; height: var(--ws-header) !important; padding: 0 4px !important; align-items: center !important; }
:host-context(html[data-wme-studio="on"]):host(wz-header) ::slotted(wz-header-controls) { min-width: 0; padding-block: 0 !important; align-self: center; }
:host-context(html[data-wme-studio="on"]) .wz-header-branding { padding-inline: 6px !important; }
:host-context(html[data-wme-studio="on"]):host(wz-header-branding) { display: flex !important; align-items: center !important; justify-content: flex-start !important; flex: 0 0 auto !important; width: auto !important; align-self: stretch; }
:host-context(html[data-wme-studio="on"]) .wz-header-branding { display: flex !important; align-items: center !important; justify-content: flex-start !important; width: auto !important; height: 100%; box-sizing: border-box; }
:host-context(html[data-wme-studio="on"]) .wz-header-controls { min-width: 0; }

:host-context(html[data-wme-studio="on"]) .wz-navigation-drawer { background: var(--ws-bg) !important; box-shadow: none !important; }
:host-context(html[data-wme-studio="on"]) .navigation-button {
  border-radius: var(--ws-radius) !important; color: var(--ws-secondary) !important;
  margin-inline: 6px !important; width: calc(100% - 12px) !important;
  min-height: 48px; box-sizing: border-box; font-family: var(--ws-font) !important;
}
/* The color layer is clipped to the rounded button: no square plate behind it. */
:host-context(html[data-wme-studio="on"]) .wz-navigation-item { background: transparent !important; box-shadow: none !important; }
:host-context(html[data-wme-studio="on"]) .navigation-button { position: relative; overflow: hidden !important; isolation: isolate; }
:host-context(html[data-wme-studio="on"]) .navigation-button .color-layer { border-radius: inherit !important; }
:host-context(html[data-wme-studio="on"]) .navigation-button:hover { background: var(--ws-hover) !important; color: var(--ws-text) !important; }
:host-context(html[data-wme-studio="on"]) .wz-navigation-item:is(.active,.selected) .navigation-button,
:host-context(html[data-wme-studio="on"]) .navigation-button.selected,
:host-context(html[data-wme-studio="on"]):host([selected]) .navigation-button,
:host-context(html[data-wme-studio="on"]):host([active]) .navigation-button {
  background: var(--ws-accent-soft) !important; color: var(--ws-text) !important;
  box-shadow: inset 3px 0 var(--ws-accent) !important;
}
:host-context(html[data-wme-studio="on"]) .wz-navigation-item .item-content { font-size: 11px !important; font-weight: 550; }

:host-context(html[data-wme-studio="on"]) :is(.wz-text-input,.wz-select) {
  border-radius: var(--ws-radius) !important;
  font-size: 13px !important;
}
:host-context(html[data-wme-studio="on"]) .wz-text-input-inner-container {
  border-radius: var(--ws-r-start, var(--ws-radius)) var(--ws-r-end, var(--ws-radius)) var(--ws-r-end, var(--ws-radius)) var(--ws-r-start, var(--ws-radius)) !important;
  background: var(--ws-field) !important; border: 1px solid var(--ws-border) !important;
  box-shadow: none !important; min-height: var(--ws-control); box-sizing: border-box;
}
:host-context(html[data-wme-studio="on"]) .wz-text-input-inner-container:focus-within { border-color: var(--ws-accent) !important; box-shadow: 0 0 0 2px var(--ws-focus) !important; }
:host-context(html[data-wme-studio="on"]) .wz-text-input-inner-container input { color: var(--ws-text) !important; font-size: 13px !important; line-height: 20px !important; background: transparent !important; border: 0 !important; border-radius: inherit !important; }
:host-context(html[data-wme-studio="on"]) .wz-text-input-inner-container::after { display: none !important; }
:host-context(html[data-wme-studio="on"]) .wz-text-input-inner-container input:focus-visible { outline: none !important; }
:host-context(html[data-wme-studio="on"]) .wz-text-input-inner-container input::placeholder { color: var(--ws-muted) !important; opacity: 1; }
:host-context(html[data-wme-studio="on"]) .wz-text-input:is(.error,.invalid,.has-error) .wz-text-input-inner-container,
:host-context(html[data-wme-studio="on"]):host([status="error"]) .wz-text-input-inner-container { border-color: var(--alarming_variant, #e42828) !important; }
:host-context(html[data-wme-studio="on"]) .wz-text-input.has-success .wz-text-input-inner-container { border-color: var(--safe_variant, #118742) !important; }
:host-context(html[data-wme-studio="on"]) .wz-text-input-inner-container:has(input:disabled) { opacity: .55; }
:host-context(html[data-wme-studio="on"]) :is(textarea,.wz-select .selected-option) { border-radius: var(--ws-radius) !important; background: var(--ws-field); color: var(--ws-text); border-color: var(--ws-border); }

/* Style the actual select trigger; Waze still owns placement and menu flipping. */
:host-context(html[data-wme-studio="on"]) .wz-select .select-box { background: var(--ws-field) !important; color: var(--ws-text); border: 1px solid var(--ws-border) !important; border-radius: var(--ws-radius) !important; height: var(--wz-select-height, var(--ws-control)); padding-inline: 12px !important; }
:host-context(html[data-wme-studio="on"]) .wz-select .select-box::after { display: none !important; }
:host-context(html[data-wme-studio="on"]) .wz-select .selected-value-wrapper { line-height: 20px !important; min-width: 0; gap: 8px; }
:host-context(html[data-wme-studio="on"]) .wz-select .selected-value { min-width: 0; }
:host-context(html[data-wme-studio="on"]) .wz-select .select-box:focus-within,
:host-context(html[data-wme-studio="on"]) .wz-select.expanded .select-box { border-color: var(--ws-accent) !important; box-shadow: 0 0 0 2px var(--ws-focus); }
:host-context(html[data-wme-studio="on"]) .wz-select .select-box:focus-visible { outline: 2px solid var(--ws-accent) !important; outline-offset: 2px; }
:host-context(html[data-wme-studio="on"]) .wz-select.has-error .select-box { border-color: var(--alarming_variant, #e42828) !important; }
:host-context(html[data-wme-studio="on"]) .wz-select.has-success .select-box { border-color: var(--safe_variant, #118742) !important; }
:host-context(html[data-wme-studio="on"]) .wz-select.disabled .select-box { opacity: .55; color: var(--ws-muted); }
:host-context(html[data-wme-studio="on"]) .wz-select wz-menu { --wz-menu-margin-top: 0px; }

:host-context(html[data-wme-studio="on"]) .wz-menu > .options-container > .options-wrapper {
  background: var(--ws-raised) !important; color: var(--ws-text) !important;
  border: 1px solid var(--ws-border) !important; border-radius: var(--ws-panel-radius) !important;
  box-shadow: var(--ws-shadow) !important; padding: 4px 0 !important;
  scrollbar-width: thin; scrollbar-color: var(--ws-border-strong) transparent;
}
:host-context(html[data-wme-studio="on"]) :is(.wz-menu-item,.wz-menu-sub-menu) {
  background: var(--ws-raised) !important; color: var(--ws-text); font-size: 13px !important;
  line-height: 20px !important; min-height: var(--wz-menu-option-height, calc(var(--ws-control) + 2px));
  padding: 0 12px !important; box-sizing: border-box;
}
:host-context(html[data-wme-studio="on"]) :is(.wz-menu-item,.wz-menu-sub-menu) .content { align-items: center; min-width: 0; }
:host-context(html[data-wme-studio="on"]) :is(.wz-menu-item,.wz-menu-sub-menu):is(:hover,.highlighted):not(.disabled) { background: var(--ws-hover) !important; }
:host-context(html[data-wme-studio="on"]) .wz-menu-item:is(.selected,.active):not(.disabled) { background: var(--ws-accent-soft) !important; }
:host-context(html[data-wme-studio="on"]) :is(.wz-menu-item,.wz-menu-sub-menu).disabled { color: var(--ws-muted); }
:host-context(html[data-wme-studio="on"]) .wz-menu-option-divider { background: var(--ws-border) !important; }
:host-context(html[data-wme-studio="on"]) .wz-menu-title { display: flex; align-items: center; background: var(--ws-raised) !important; color: var(--ws-muted); font-size: 11px; line-height: 16px !important; min-height: 28px; padding: 6px 12px !important; letter-spacing: .03em; }
:host-context(html[data-wme-studio="on"]) .options-wrapper::-webkit-scrollbar { width: 7px; height: 7px; }
:host-context(html[data-wme-studio="on"]) .options-wrapper::-webkit-scrollbar-track { background: transparent; }
:host-context(html[data-wme-studio="on"]) .options-wrapper::-webkit-scrollbar-thumb { background: var(--ws-border-strong); border: 2px solid transparent; background-clip: padding-box; border-radius: 8px; }

/* Compound category fields get one outline; their nested input stays editable. */
:host-context(html[data-wme-studio="on"]) .input-with-chips-area-container { background: var(--ws-field) !important; border: 1px solid var(--ws-border) !important; border-radius: var(--ws-radius) !important; min-height: var(--ws-control); padding: 4px 6px; gap: 4px; box-sizing: border-box; align-items: center; }
:host-context(html[data-wme-studio="on"]) .input-with-chips-area-container:focus-within { border-color: var(--ws-accent) !important; box-shadow: 0 0 0 2px var(--ws-focus); }
:host-context(html[data-wme-studio="on"]) .input-with-chips-area-container:has(wz-text-input[error-message]:not([error-message=""])) { border-color: var(--alarming_variant, #e42828) !important; }
:host-context(html[data-wme-studio="on"]) .input-with-chips-area-container-left-flex { flex: 1 1 auto; align-items: center; min-width: 0; gap: 4px; }
:host-context(html[data-wme-studio="on"]) .input-with-chips-area-container .input-text-area { flex: 1 1 80px; min-width: 0; max-width: 100%; }
:host-context(html[data-wme-studio="on"]) .input-with-chips-area-container .input-area-container-right-flex { flex: 0 0 auto; align-self: flex-start; }
:host-context(html[data-wme-studio="on"]) .input-with-chips-area-container .remove-all-chips-container { justify-content: center; min-height: 24px; }
:host-context(html[data-wme-studio="on"]) .input-with-chips-area-container .autocomplete-hidden-input { font-size: 13px !important; line-height: 20px; }
:host-context(html[data-wme-studio="on"]) #multi-select-container .chip-container { min-width: 0; max-width: 100%; gap: 4px !important; padding: 0 !important; align-items: center; }
:host-context(html[data-wme-studio="on"]) #multi-select-container .multi-select-chips-remove-all { margin: 0 !important; }
:host-context(html[data-wme-studio="on"]):host(.multi-select-chips-remove-all) .wz-button { width: 24px !important; min-width: 24px !important; height: 24px !important; min-height: 24px; padding: 0 !important; }
:host-context(html[data-wme-studio="on"]):host-context(.input-with-chips-area-container):host(wz-text-input) { min-width: 0 !important; width: 100%; }
:host-context(html[data-wme-studio="on"]):host-context(.input-with-chips-area-container) .wz-text-input-inner-container { border: 0 !important; border-radius: 0 !important; background: transparent !important; box-shadow: none !important; height: 24px !important; min-height: 24px !important; }
:host-context(html[data-wme-studio="on"]):host-context(.input-with-chips-area-container) .wz-text-input-inner-container input { min-width: 0 !important; padding-inline: 4px !important; }
:host-context(html[data-wme-studio="on"]):host-context(wz-multi-select):host(wz-chip) { min-width: 0; max-width: 100%; }
:host-context(html[data-wme-studio="on"]):host-context(wz-multi-select) .wz-chip { border-radius: var(--ws-radius) !important; max-width: 100%; line-height: 18px !important; }
:host-context(html[data-wme-studio="on"]):host-context(wz-multi-select) .wz-chip .remove-icon { display: inline-flex; align-items: center; flex-shrink: 0; }
:host-context(html[data-wme-studio="on"]) :is(.simple-item,.simple-sub-menu-item) { --wz-menu-option-height: calc(var(--ws-control) + 2px) !important; }
:host-context(html[data-wme-studio="on"]) .simple-item .wz-autocomplete-item { height: auto !important; min-height: 20px; }

:host-context(html[data-wme-studio="on"]) .wz-section-header { background: var(--ws-surface); border-color: var(--ws-border) !important; padding-block: 12px !important; }
:host-context(html[data-wme-studio="on"]) .wz-section-header .headline { font-size: 14px !important; font-weight: 650 !important; color: var(--ws-text); letter-spacing: -.02em; }
:host-context(html[data-wme-studio="on"]) .wz-card { border-radius: var(--ws-panel-radius) !important; border-color: var(--ws-border) !important; box-shadow: none !important; }
:host-context(html[data-wme-studio="on"]) .wz-tab { font-size: 12px !important; font-weight: 600 !important; }
:host-context(html[data-wme-studio="on"]) .wz-tab:is(.active,.selected) { color: var(--ws-text); border-color: var(--ws-accent); }
:host-context(html[data-wme-studio="on"]) .wz-empty-state { padding: 32px 22px; gap: 16px; }
:host-context(html[data-wme-studio="on"]) .wz-empty-state > img { width: 128px !important; height: 128px !important; object-fit: contain; }
:host-context(html[data-wme-studio="on"]) .wz-empty-state .headline { color: var(--ws-text); font-size: 16px; line-height: 1.35; font-weight: 650; }
:host-context(html[data-wme-studio="on"]) .wz-empty-state .description { color: var(--ws-secondary); font-size: 13px; line-height: 1.65; }
:host-context(html[data-wme-studio="on"]) :is(.wz-dialog,.wz-modal) { border-radius: var(--ws-panel-radius) !important; border: 1px solid var(--ws-border); background: var(--ws-raised); box-shadow: var(--ws-shadow); }
:host-context(html[data-wme-studio="on"]) .wz-checkbox { font-size: 13px; color: var(--ws-text); }
:host-context(html[data-wme-studio="on"]) .wz-tooltip-content-holder {
  background-color: var(--wz-tooltip-content-background-color, var(--ws-raised)) !important;
  color: var(--wz-tooltip-content-color, var(--ws-text)) !important;
}
:host-context(html[data-wme-studio="on"]) .wz-slider { border-radius: 20px !important; }
:host-context(html[data-wme-studio="on"]) .wz-snackbar { border-radius: var(--ws-panel-radius) !important; box-shadow: var(--ws-shadow) !important; }
:host-context(html[data-wme-studio="on"][data-wme-studio-motion="reduced"]) :is(.wz-button,.navigation-button,.wz-navigation-drawer,.wz-page-wrapper,.wz-card) { transition: none !important; }
`;
