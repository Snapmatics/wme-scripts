(() => {
  'use strict';
  if (!/(?:^|\/)editor(?:\/|$)/i.test(location.pathname)) return;
  if (globalThis.__wmeStudioRunning) return;
  globalThis.__wmeStudioRunning = true;
  const config = globalThis.WMEStudioSettings;
  const root = document.documentElement;
  const attr = (key, value) => {
    const name = 'data-wme-studio' + (key ? '-' + key : '');
    if (value == null) root.removeAttribute(name);
    else if (root.getAttribute(name) !== String(value)) root.setAttribute(name, value);
  };
  let settings = { ...config.defaults };
  let ready = false;
  let resizeFrame = 0;
  const systemTheme = matchMedia('(prefers-color-scheme: dark)');
  const reducedMotion = matchMedia('(prefers-reduced-motion: reduce)');

  function nativeTheme() {
    for (const element of [root, document.body]) {
      if (!element) continue;
      const value = element.getAttribute('wz-theme') || element.getAttribute('data-theme');
      if (value === 'dark' || value === 'light') return value;
      if (element.classList.contains('dark') || element.classList.contains('dark-theme')) return 'dark';
    }
    return systemTheme.matches ? 'dark' : 'light';
  }
  function apply() {
    if (!ready) return;
    if (!settings.enabled) {
      for (const key of ['', 'theme', 'density', 'corners', 'addons', 'motion']) attr(key, null);
      for (const name of ['--ws-accent', '--ws-on-accent', '--ws-sidebar']) root.style.removeProperty(name);
    } else {
      root.style.setProperty('--ws-accent', settings.accent);
      root.style.setProperty('--ws-on-accent', config.ink(settings.accent));
      root.style.setProperty('--ws-sidebar', settings.sidebar + 'px');
      attr('theme', settings.theme === 'waze' ? nativeTheme() : settings.theme);
      attr('density', settings.density);
      attr('corners', settings.corners);
      attr('addons', settings.addons ? 'on' : 'off');
      attr('motion', settings.motion || reducedMotion.matches ? 'reduced' : 'normal');
      attr('', 'on');
    }
    cancelAnimationFrame(resizeFrame);
    resizeFrame = requestAnimationFrame(() => window.dispatchEvent(new Event('resize')));
  }

  // Only Waze custom elements are traversed/styled. The map's SVG/tile trees
  // are excluded; no native node is cloned, reparented, clicked or replaced.
  const ignored = '.olMapViewport, .olLayerDiv, #render-root, script, style, svg, canvas, iframe';
  const roots = new Map();
  const pending = new Set();
  const queue = new Set();
  let scanTimer = 0;
  function excluded(node) { return node.nodeType !== 1 || node.matches(ignored) || !!node.closest('.olMapViewport, .olLayerDiv, #render-root'); }
  function discover(start) {
    if (start.nodeType === 1 && excluded(start)) return;
    if (start.nodeType === 1) inspect(start);
    const walker = document.createTreeWalker(start, NodeFilter.SHOW_ELEMENT, {
      acceptNode: node => node.matches(ignored) ? NodeFilter.FILTER_REJECT : NodeFilter.FILTER_ACCEPT
    });
    while (walker.nextNode()) inspect(walker.currentNode);
  }
  function inspect(host) {
    if (!host.localName.startsWith('wz-')) return;
    const shadow = host.shadowRoot;
    if (!shadow) { pending.add(host); return; }
    pending.delete(host);
    if (roots.has(shadow)) return;
    const style = document.createElement('style');
    style.dataset.wmeStudioComponents = '1';
    style.textContent = globalThis.WMEStudioComponents;
    shadow.append(style);
    const observer = new MutationObserver(records => {
      // Stencil can replace a root's children during a rerender.
      if (!style.isConnected && host.isConnected) shadow.append(style);
      collect(records);
    });
    roots.set(shadow, { host, style, observer });
    observer.observe(shadow, { childList: true, subtree: true });
    discover(shadow);
  }
  function collect(records) {
    for (const record of records) {
      for (const node of record.addedNodes) if (node.nodeType === 1 && !excluded(node)) queue.add(node);
    }
    if (queue.size && !scanTimer) scanTimer = setTimeout(() => {
      scanTimer = 0;
      const added = [...queue]; queue.clear();
      for (const node of added) if (node.isConnected) discover(node);
    }, 60);
  }
  const observer = new MutationObserver(collect);
  observer.observe(root, { childList: true, subtree: true });
  const themeObserver = new MutationObserver(() => {
    if (ready && settings.enabled && settings.theme === 'waze') attr('theme', nativeTheme());
  });
  const observeTheme = node => node && themeObserver.observe(node, { attributes: true, attributeFilter: ['wz-theme', 'data-theme', 'class'] });
  observeTheme(root);
  function boot() { observeTheme(document.body); discover(root); }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot, { once: true });
  else boot();

  // Handles custom elements upgraded after insertion without patching attachShadow
  // or entering the page's JavaScript world. Also releases detached roots.
  setInterval(() => {
    if (document.hidden) return;
    for (const host of pending) {
      if (!host.isConnected) pending.delete(host);
      else inspect(host);
    }
    for (const [shadow, item] of roots) if (!item.host.isConnected) {
      item.observer.disconnect(); roots.delete(shadow);
    }
  }, 1500);
  chrome.storage.onChanged.addListener((items, area) => {
    if (area !== 'local' || !Object.keys(items).some(key => key.startsWith('wmeStudio.'))) return;
    settings = config.changes(settings, items); ready = true; apply();
  });
  systemTheme.addEventListener('change', apply);
  reducedMotion.addEventListener('change', apply);
  config.read().then(value => { settings = value; ready = true; apply(); }).catch(error => {
    // Leave the native editor intact if extension storage is unavailable.
    console.warn('[WME Studio] Appearance settings could not be loaded.', error.message);
  });
})();
