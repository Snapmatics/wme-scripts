# WME Merge Alternate Addresses

Batch apply and manage **alternate street names** across multiple selected segments in **Waze Map Editor (WME)**.

This userscript adds a modern floating panel that:
- builds a **combined list** of alternates found in your current selection,
- shows **Present vs Missing counts** per alternate,
- lets you **Add to missing** or **Remove alternate** in one click,
- and provides a quick **Undo** for the last operation.

> Unofficial tool. Not affiliated with Waze.

---

## Features

### Alternate merge workflow (selection-based)
- **Alternate union view**: shows all alternate names found in the selected segments.
- **Coverage chips per alternate**: `Present in X/Y` and `Missing in Z`.
- **Add to missing**: applies an alternate only to segments that don’t have it.
- **Remove alternate**: removes an alternate from segments where it exists.
- Buttons automatically **disable** when an action isn’t applicable.

### Review + cleanup
- Expand **Present** / **Missing** lists to see exactly which segments are affected.
- **Zoom-to-segment** button for fast verification.
- **Remove from this segment only** directly from the “Present” list (surgical cleanup).

### Safety + UX
- **Undo last operation** (via WME undo when available).
- Modern **floating / glassy UI** with smooth open/close behavior.
- **Minimize to a circular launcher** and drag it around.
- **Auto-expand** when you select multiple segments that already contain alternates (so you don’t miss it).
- Performance-friendly list rendering (shows a limited number of rows by default with a “show more/less” toggle).
- Remembers panel state/position (local storage).

---

## Installation

1. Install **Tampermonkey** (Chrome/Edge) or **Violentmonkey**.
2. Create a new userscript.
3. Paste the script code from `WME-Merge-Alternate-Addresses.user.js` and save.
4. Open Waze Map Editor:
   - Production: `https://www.waze.com/editor`
   - Beta: `https://www.waze.com/beta_editor`

---

## How to use

1. In WME, **select 2+ segments**.
2. Open the **Merge Alternate Addresses** panel (or let it auto-expand).
3. For each alternate:
   - Click **Add to missing** to apply it to the remaining segments
   - or **Remove alternate** to remove it from segments where present
4. Expand **Present** / **Missing** to review affected segments.
5. Use **Undo** if you need to revert the last action.

---

## Compatibility

- Designed for WME with the **WME SDK** available.
- Works on both production and beta editor URLs (as long as the SDK APIs used by the script are present).

---

## Notes / Disclaimer

- This tool performs edits on selected map objects. Always review changes and follow your community’s editing guidelines.
- If something looks off, hit **Undo** and re-check your selection.

---

## License

MIT
